# Marked screenshot review — v98.63.4

## Source-derived observations
1. Currency picker screenshot: the header area is visually crowded and currency identifiers/names appear to run together.
2. Currency converter screenshot: the quote card repeats provider/update status and last-checked timestamps below a quote line that already includes pair, rate date and provider.
3. Bottom navigation screenshot: a large unused strip remains between the dock content and the Android system navigation area.

## Changes
- Native fallback currency option labels now read `CODE — localized currency name`.
- Custom picker header is constrained to one ellipsized line; search remains separate; option rows are full-width, vertically stacked, and scrollable.
- Exchange-rate quote remains visible; status and refresh timestamps are visually hidden but retained in the accessibility tree for live announcements and assistive technology.
- Bottom dock is fixed to its 68px design height without a second CSS safe-area reservation, matching the supplied capture where the WebView ends above the Android system navigation area.
- Convert remains enabled and touch-sized; vertical spacing around the quote and action is reduced.

## Verification boundary
Automated source/build tests can verify CSS/JS and package consistency. Exact rendering, WebView inset behavior, native picker behavior and keyboard interaction still require an install on the target Android device.
