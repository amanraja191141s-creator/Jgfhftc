# Release Verification — v98.63.9.30 CI Hotfix

- Source baseline: locally available v98.63.9.30 project ZIP. GitHub repo page showed archive with matching name and approximately 1.63 MB display size; raw ZIP retrieval was blocked in this environment, so byte-for-byte remote comparison was unavailable.
- Confirmed workflow cache gate was stale: it expected a v29 cache namespace but the v30 source uses the v30 namespace.
- Corrected CI to derive cache namespace from the selected source worker and verify generated `www/service-worker.js` contains the same value.
- Corrected the workflow required-file list to reference the existing `tests/v98634-marked-screenshot-cleanup.test.mjs` file rather than a nonexistent filename.
- Added two cache/file-path regression checks to the release suite.
- All 38 workflow-required files are present and non-empty.
- `npm test`: 40/40 passed.
- `npm run build:web`: PASS, 13 required assets verified.
- YAML parse: PASS; duplicate workflow copies synchronized.
- ZIP integrity: verified.
- Android SDK/APK and physical-device testing: not performed.
