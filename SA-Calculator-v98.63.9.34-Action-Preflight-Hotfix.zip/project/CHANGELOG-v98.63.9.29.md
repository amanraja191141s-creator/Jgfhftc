# Changelog — v98.63.9.29

## Video-driven scientific key size and geometry correction

- Scientific drawer top and height follow the live main-keypad rectangle instead of fixed viewport percentages.
- Drawer width stays capped at 94vw / 680px; open/closed/drag transforms use the existing swipe lifecycle.
- Scientific function buttons use the main keypad font scale (18–22 CSS px), regular unboxed text keys, and compact More/close circles.
- The primary and secondary matrices remain 4×4, with secondary panel scroll/overscroll containment and accessible labels.
- INV stays one-shot inverse trig modifier; expression insertion and keyboard Escape closure remain wired.
- Package/app/PWA/cache/workflow identities synchronized to `1.98.76-v98.63.9.29`, Android versionCode `1098077`.

## Validation

- 78/78 automated release tests passed.
- `npm run build:web` passed; all 13 required assets present.
- Root/web CSS copy equality, JS syntax, workflow source checks, ZIP integrity and YAML parse passed.
- Browser/device visual and APK build checks are pending due to restricted browser runtime in this environment.
