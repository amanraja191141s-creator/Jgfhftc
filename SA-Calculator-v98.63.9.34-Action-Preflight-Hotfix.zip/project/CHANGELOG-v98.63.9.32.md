# v98.63.9.33 — Tools result visibility

- Fixed the shared Tools keypad Equals path so calculation no longer dismisses the docked keypad.
- Added a shared result-reveal routine that uses the live keypad boundary, keeping tool result cards visible above the keypad.
- Applied the same behaviour after explicit Calculate buttons across tool screens.
- Kept keypad dismissal for navigation/back/close actions and left the main calculator keypad unchanged.
- Bumped app version and Android versionCode to avoid stale WebView/service-worker assets.
