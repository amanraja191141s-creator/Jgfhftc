# Micro-level audit — v98.63.9.33

## Source-video observations

The supplied 720×1560 screen recording shows the Tip Calculator using a shared four-column numeric keypad docked at the bottom. Focus moves among Bill Amount, Tip Rate and Number of People while the keypad remains available. A calculated Results card is then shown in the form area. The reported defect is that result visibility/layout changes while the keypad is already active.

## Root cause

The shared keypad's `EQUAL` branch recalculated the active tool, persisted values, and immediately called `closePopupKeypad()`. This made result visibility depend on a keypad dismissal transition rather than keeping the result and keypad in a stable simultaneous layout. Explicit Calculate buttons also had no common post-calculation result-reveal behaviour.

## Changes

1. Removed the automatic keypad close from the shared `EQUAL` action.
2. Added `revealToolResultsAboveKeypad()` for all numeric Tools. It measures the real fixed keypad top edge after the result DOM update and scrolls the result card into the unobstructed area above it.
3. Applied the same reveal helper after explicit tool Calculate buttons (including the shared Unit Price compare action).
4. Preserved normal keypad dismissal through navigation, Android Back/history, and the explicit close action.
5. Kept the main calculator keypad path unchanged.
6. Bumped app version to `1.98.78-v98.63.9.33`, Android versionCode to `1098080`, and the service-worker cache namespace to avoid stale runtime assets.
7. Synced root and generated web assets and both workflow copies.

## Verification

- `npm run build:web`: PASS.
- `npm run test:release`: 47 passed, 0 failed.
- `node --check assets/js/app.js`: PASS.
- Android workflow YAML parse: PASS; `android-build` job present.
- Workflow mirrors byte-identical: PASS.
- Root/www HTML, JS, CSS and service-worker mirrors: PASS.
- ZIP integrity: verified after packaging.

## Not claimed

A GitHub-hosted Gradle build, generated APK, and physical Android device interaction test were not run in this local verification. These must be confirmed by the next GitHub Actions run/device test.
