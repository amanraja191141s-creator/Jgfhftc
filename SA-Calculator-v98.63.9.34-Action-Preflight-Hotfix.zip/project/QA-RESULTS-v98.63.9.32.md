# QA Results — v98.63.9.33

## Action preflight correction and video-driven Tools keypad/result correction

- Shared numeric keypad remains docked after the Equals action.
- Tool result cards are measured against the actual keypad top edge and scrolled into the unobstructed area above it.
- Explicit Calculate buttons use the same result-reveal behaviour.
- Tool navigation and explicit keypad dismissal still close the keypad normally.
- Main calculator keypad path is unchanged.

## Verification

- `npm run build:web`: passed.
- `npm run test:release`: 47 passed, 0 failed.
- Workflow YAML parsing: passed for both copies; copies are byte-identical.
- Android Gradle/APK build is not claimed as locally executed.
