# Micro-level audit — v98.63.9.23

## Source reviewed
- Previous complete source: v98.63.9.22 ZIP.
- Previous workflow: v98.63.9.22 Android workflow.
- Current source areas: Other Calculator grouped catalogue, scientific drawer markup, CSS cascade, scientific event delegation, angle preference persistence, service worker, Android workflow and regression suite.

## Additional defects addressed
1. Scientific DEG/RAD control initially displayed the generic `DRG` label even when a saved DEG or RAD preference existed. It now initializes from the persisted mode before user interaction.
2. Angle-mode state was not exposed consistently to assistive technology. `aria-label` and `aria-pressed` now track the active mode on initialization and every toggle.
3. Short-height media rules reduced scientific function targets to 42px, contradicting the primary 48px touch-target rule. The short-screen override now retains 48px targets and allows the scientific workspace to scroll.
4. Tool and scientific controls needed a clear keyboard-only focus indicator. Added high-contrast `:focus-visible` outlines.

## Preserved
- Existing 3-column grouped Tools catalogue and all 16 tool destinations.
- Existing Unit Converter category-first flow and conversion engine.
- Scientific expression engine, function token insertion, INV one-shot behavior, cursor editing, memory/history actions, right-edge drawer gesture and full-width normal keypad.
- Existing tool calculation engines.

## Verification
- Focused release suite and Android web bundle results are recorded in `QA-RESULTS-v98.63.9.23.md`.
- ZIP CRC integrity and YAML syntax are verified at packaging time.
- Native Android APK installation, physical-device screenshots, touch latency and frame pacing are not certified in this environment.
