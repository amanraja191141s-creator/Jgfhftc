# QA Results — v98.63.9.15

## Screenshot comparison / root cause
The v98.63.9.14 Android capture showed a short display, oversized keypad region, and a large unused strip above the bottom navigation. The prior child percentage rules were being applied while the active screen did not reliably stretch to the full viewport height in Android WebView.

## Fix
- Explicitly stretch `#screen-viewport` and its active calculator child across the complete available height.
- Match the supplied reference proportions: 53% display and 47% keypad on portrait screens.
- Keep the bottom navigation as a separate fixed-height flex sibling.
- Restore near-full-cell keypad buttons, preserving all 19 controls and the two-column zero key.
- Keep a compact landscape-specific side-by-side layout.
- Bump service-worker cache namespace to prevent stale Android CSS.

## Validation
Automated checks are run in the included Android workflow. Physical-device installation and pixel comparison remain to be completed on the target phone; no claim of device certification is made.
