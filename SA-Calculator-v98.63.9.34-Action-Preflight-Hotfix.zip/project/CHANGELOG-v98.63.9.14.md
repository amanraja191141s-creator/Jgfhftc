# v98.63.9.14 — Calculator display/keypad boundary correction

- Matched the latest marked Android screenshot: the calculator expression + live preview/result region now occupies 39% of the calculator workspace.
- Constrained the complete five-row keypad to the remaining 61%, with each key centered and sized within its grid cell.
- Preserved the 4-column layout, zero-key span, operator column, expression editing, live preview, result mode, bottom navigation and calculator actions.
- Added a landscape-specific compact arrangement and short-height spacing rules.
- Refreshed the service-worker cache namespace and Android workflow identity to prevent stale CSS from masking the fix.
- Android device visual validation remains a manual release check.
