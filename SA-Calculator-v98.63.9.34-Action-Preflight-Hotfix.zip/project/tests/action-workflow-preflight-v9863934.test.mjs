import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const workflow = readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const serviceWorker = readFileSync(path.join(root, 'service-worker.js'), 'utf8');
const pkg = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8'));
test('workflow identity and Android version code match current release', () => {
  assert.equal(pkg.version, '1.98.78-v98.63.9.34');
  assert.equal(pkg.androidVersionCode, 1098082);
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.78-v98\.63\.9\.34'/);
  assert.match(workflow, /v98\.63\.9\.34 release regression suite/);
});
test('Android SDK is installed before exact adb, API and aapt checks', () => {
  assert.match(workflow, /uses: gradle\/actions\/setup-gradle@v4/);
  assert.match(workflow, /uses: android-actions\/setup-android@v3/);
  assert.match(workflow, /platforms;android-35/);
  assert.match(workflow, /build-tools;35\.0\.0/);
  assert.match(workflow, /platform-tools/);
  assert.match(workflow, /platform-tools\/adb/);
  assert.match(workflow, /build-tools\/35\.0\.0\/aapt/);
});
test('workflow validates current release source files and explicit release tests', () => {
  assert.match(workflow, /tests\/v9863934-full-width-tool-keypad\.test\.mjs/);
  assert.match(workflow, /tests\/action-workflow-preflight-v9863934\.test\.mjs/);
  assert.doesNotMatch(workflow, /v98\.63\.9\.33/);
});
test('npm install cannot create incidental lockfiles and uses retries', () => {
  assert.match(workflow, /npm install --no-package-lock --no-audit --no-fund --fetch-retries=5 --fetch-timeout=120000/);
});
test('workflow mirror is source-root based and checks APK metadata', () => {
  assert.match(workflow, /aapt.*dump badging|dump badging/);
  assert.match(workflow, /sha256sum/);
  assert.match(workflow, /Generate Android project if missing/);
  assert.match(workflow, /rootIsExact = candidates\.some/);
  assert.match(workflow, /Ignoring stale archive/);
  assert.match(workflow, /if\(!selected\)/);
});

test('service-worker cache namespace and workflow preflight match this exact release', () => {
  assert.match(serviceWorker, /v9863934/);
  assert.match(workflow, /sw\.includes\('v9863934'\)/);
  assert.doesNotMatch(workflow, /sw\.includes\('v9863933'\)/);
});
