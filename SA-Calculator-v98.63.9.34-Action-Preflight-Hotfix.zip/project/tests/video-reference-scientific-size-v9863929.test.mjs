import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const layer=css.slice(css.lastIndexOf('v98.63.9.29 — video pass: scientific keys use calculator-key typography'));
test('video-sized scientific overlay is measured from the basic keypad band, not viewport height',()=>{
 assert.match(layer,/top:var\(--sci-drawer-top,auto\)!important/); assert.match(layer,/height:var\(--sci-drawer-height,auto\)!important/);
 assert.match(layer,/width:min\(94vw,680px\)!important/); assert.doesNotMatch(layer,/height:56%\!important/);
 assert.match(js,/keypadRect\.top - calcRect\.top/); assert.match(js,/keypadRect\.height/);
});
test('scientific labels use the standard keypad font scale and non-oversized INV',()=>{
 assert.match(layer,/font-size:clamp\(18px,5\.2vw,22px\)!important/);
 assert.match(layer,/#sci-shift-toggle[\s\S]*?border-radius:0\!important/);
 assert.match(layer,/#sci-more-toggle[\s\S]*?width:min\(58%,54px\)!important/);
 assert.match(layer,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/); assert.match(layer,/grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/);
});
test('secondary panel stays same-size 4x4, and click/touch controls remain wired',()=>{
 assert.match(layer,/scientific-more-functions:not\(\[hidden\]\)[\s\S]*?inset:0\!important/);
 assert.match(html,/id="sci-more-toggle" aria-expanded="false" aria-controls="sci-more-functions"/);
 assert.match(html,/id="sci-more-page-close"/); assert.match(js,/expanded\?'Close additional scientific functions':'More scientific functions'/);
 assert.match(js,/pointerdown/); assert.match(js,/pointerup/); assert.match(js,/pointercancel/);
});
test('v98.63.9.29 source identity and workflow audit compatibility stay synchronized',()=>{
 assert.equal(pkg.version,'1.98.76-v98.63.9.29'); assert.equal(pkg.androidVersionCode,1098077);
 assert.match(html,/1\.98\.76-v98\.63\.9\.29/); assert.match(js,/APP_VERSION = '1\.98\.76-v98\.63\.9\.29'/);
 const wf=fs.readFileSync('.github/workflows/main.yml','utf8'); assert.match(wf,/audit_candidates=\(MICRO-LEVEL-AUDIT-v98\.63\.9\.29\.md MICRO-AUDIT-v98\.63\.9\.29\.md MICRO-LEVEL-AUDIT-v98\.63\.9\.28\.md MICRO-AUDIT-v98\.63\.9\.28\.md\)/);
});
