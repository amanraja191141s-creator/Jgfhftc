import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const workflowPath = path.join(root, 'Android-Workflow-v98.63.9.32.yml');
const workflow = fs.readFileSync(workflowPath, 'utf8');

test('Android workflow required source manifest is complete before Actions starts', () => {
  const start = workflow.indexOf('required_files=(');
  const end = workflow.indexOf('\n          )', start);
  assert.ok(start >= 0 && end > start, 'workflow required_files array must exist');
  const block = workflow.slice(start, end);
  const required = [...block.matchAll(/^\s+([^#\s][^\s]*)\s*$/gm)].map(match => match[1]);
  assert.ok(required.length >= 30, `expected a substantial required-file gate, found ${required.length}`);
  const missing = required.filter(file => !fs.existsSync(path.join(root, file)) || !fs.statSync(path.join(root, file)).isFile() || fs.statSync(path.join(root, file)).size === 0);
  assert.deepEqual(missing, [], `workflow would fail before install/build because required files are missing/empty: ${missing.join(', ')}`);
});

test('workflow copies remain identical and current release QA evidence is packaged', () => {
  assert.equal(fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8'), workflow);
  assert.match(workflow, /QA-RESULTS-v98\.63\.9\.32\.md/);
  assert.match(fs.readFileSync(path.join(root, 'QA-RESULTS-v98.63.9.32.md'), 'utf8'), /Action preflight correction/);
});
