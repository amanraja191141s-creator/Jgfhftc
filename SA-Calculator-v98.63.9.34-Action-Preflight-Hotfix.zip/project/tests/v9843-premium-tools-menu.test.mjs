import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.44 replaces the old drawer tools menu with a dedicated premium Tools screen', () => {
  const html = read('index.html');
  assert.match(html, /id="screen-tools"[^>]*aria-label="Tools"/);
  const drawer = html.slice(html.indexOf('<aside id="sidebar-drawer"'), html.indexOf('</aside>'));
  assert.doesNotMatch(drawer, /Quick access|drawer-category|drawer-tool-search|All tools/);
  assert.match(html, /class="premium-tools-grid" id="premium-tools-grid"/);
  assert.match(html, /id="tools-category-list"/);
  assert.match(html, /data-tool-category="Finance"/);
  assert.match(html, /data-tool-category="Math"/);
  assert.match(html, /data-tool-category="Convert"/);
  assert.match(html, /data-tool-category="Daily"/);
  assert.doesNotMatch(html, /id="tools-search-panel" hidden/);
});

test('the premium grid exposes all 16 dedicated tools plus Scientific Calculator exactly once', () => {
  const html = read('index.html');
  const grid = html.slice(html.indexOf('id="premium-tools-grid"'), html.indexOf('id="tools-empty-state"'));
  const ids = [...grid.matchAll(/data-tool-screen="([a-z]+)"/g)].map(m => m[1]);
  const expected = ['currencies','units','discount','salestax','loan','savings','tip','unitprice','percent','gradeavg','hex','scientific','bodymetrics','date','fuelcost','fuelefficiency','worldtime'];
  assert.deepEqual(ids, expected);
  assert.equal(new Set(ids).size, expected.length);
  for (const id of expected.filter(id => id !== 'scientific')) assert.match(html, new RegExp(`id="screen-${id}"`), `missing screen ${id}`);
  assert.match(html, /id="screen-scientific"/);
  assert.doesNotMatch(html, /id="sci-modal-overlay"/);
  assert.doesNotMatch(grid, /data-tool-screen="(?:calc|settings)"/);
});

test('Tools bottom navigation opens the dedicated screen; History is a separate bottom item', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  assert.match(html, /data-bottom-nav="history"/);
  assert.match(html, /data-bottom-nav="tools"/);
  assert.match(js, /if \(target === 'tools'\) \{ switchScreen\('tools'\); return; \}/);
  assert.match(js, /if \(target === 'history'\).*btn-history-open/s);
  assert.match(js, /data-tool-screen/);
  assert.match(js, /tools-screen-search/);
  assert.match(js, /activeToolCategory/);
  assert.match(js, /data-tool-category/);
  assert.match(js, /switchScreen\(destination\)/);
  assert.doesNotMatch(js, /destination === 'scientific'.*btn-sci-open/s);
});

test('Tools keeps the SA Calculator brand header and activates the Tools tab without injecting a duplicate toolbar', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /screenId === 'calc' \|\| screenId === 'tools' \? 'SA Calculator' : translatedTitle/);
  assert.match(js, /screenId !== 'calc' && screenId !== 'tools'/);
  assert.match(js, /classList.toggle\('tools-screen-active', screenId === 'tools'\)/);
  assert.match(read('index.html'), /id="btn-tools-search"/);
  assert.match(read('index.html'), /id="btn-tools-more"/);
  assert.match(js, /screenId === 'settings' \? 'settings'/);
  assert.match(js, /nav\.hidden = !primaryScreens\.has\(screenId\)/);
});

test('premium Tools screen CSS is part of the Android production bundle and offline cache release', () => {
  const html = read('index.html');
  const builder = read('scripts/prepare-android-web.mjs');
  const sw = read('service-worker.js');
  assert.match(html,/assets\/css\/app\.css/);
  assert.match(builder,/assets\/css\/app\.css/);
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});

test('v98.44 release identity and downloadable workflow are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  const workflow = read('.github/workflows/main.yml');
  assert.equal(workflow, read('.github/workflows/main.yml'));
  assert.match(workflow, /1098065/);
});
