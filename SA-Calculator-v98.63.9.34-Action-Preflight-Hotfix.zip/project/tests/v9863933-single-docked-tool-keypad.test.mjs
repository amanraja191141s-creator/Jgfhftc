import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const js = readFileSync(new URL('../assets/js/app.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../assets/css/app.css', import.meta.url), 'utf8');

test('legacy embedded numeric tool keypads are removed; hex keypad remains specialized', () => {
  const embedded = [...html.matchAll(/<div\b[^>]*class="[^"]*\bdock-keypad\b[^"]*"[^>]*>/g)].map(x => x[0]);
  assert.equal(embedded.length, 1, 'only the dedicated hexadecimal keypad may remain embedded');
  assert.match(embedded[0], /hex-dock-keypad/);
  assert.doesNotMatch(html, /popup-keypad-overlay|popup-keypad-header|popup-input-preview|popup-val-display/);
  assert.match(html, /id="popup-keypad-sheet"[^>]*aria-label="Numeric keypad"/);
});

test('numeric tool navigation activates the first visible field and shared docked keypad', () => {
  assert.match(js, /const candidates = Array\.from\(target\.querySelectorAll\('\.input-val-box, input\[type="number"\]\.gpa-credits'\)\)/);
  assert.match(js, /if \(first\) openPopupKeypad\(first\)/);
  assert.match(js, /sheet\.classList\.add\('active'\)/);
  assert.doesNotMatch(js, /getElementById\('popup-keypad-overlay'\)/);
});

test('equals recalculates, reveals results above keypad, and never dismisses keypad', () => {
  const branch = js.match(/if \(key === 'EQUAL'\) \{([\s\S]*?)\n  \} else if \(key === 'CLR'\)/)?.[1] || '';
  assert.match(branch, /recalculateCurrentScreen\(\)/);
  assert.match(branch, /revealToolResultsAboveKeypad\(\)/);
  assert.doesNotMatch(branch, /closePopupKeypad/);
  assert.match(js, /const safeBottom = sheet\.getBoundingClientRect\(\)\.top - 14/);
});

test('all tool result scroll space accounts for the shared docked keypad', () => {
  assert.match(css, /v98\.63\.9\.33 — authoritative single docked keypad/);
  assert.match(css, /body\.tool-keypad-active #screen-viewport > \.screen\.active \.calc-scrollable/);
  assert.match(css, /padding-bottom:calc\(47dvh \+ 18px/);
  assert.match(css, /grid-row:3 \/ span 2/);
});

test('main calculator keeps its own keypad and is excluded from tool keypad auto-open', () => {
  assert.match(html, /class="main-keypad"/);
  assert.match(js, /!\['calc', 'tools', 'settings', 'favorites'\]\.includes\(screenId\)/);
});

test('rapid tool navigation cannot let a stale Android Back event close the new keypad', () => {
  assert.match(js, /pendingKeypadHistoryPopToken/);
  assert.match(js, /currentKeypadHistoryToken === poppedToken/);
  assert.match(js, /saToolKeypad: currentKeypadHistoryToken/);
});

test('unit-category selection opens the shared keypad after its amount field becomes visible', () => {
  assert.match(js, /STATE\.currentScreen === 'units' && workspace && !workspace\.hidden/);
  assert.match(js, /openPopupKeypad\(amount\)/);
  assert.doesNotMatch(html, /class="dock-keypad"/);
});
