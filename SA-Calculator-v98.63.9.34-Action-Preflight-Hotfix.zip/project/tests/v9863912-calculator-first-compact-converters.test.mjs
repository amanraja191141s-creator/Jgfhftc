import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = p => fs.readFileSync(path.join(root,p),'utf8');
test('v98.63.9.12 makes calculator the primary header-free workspace',()=>{
  const html=read('index.html'), css=read('assets/css/app.css'), pkg=JSON.parse(read('package.json'));
  assert.equal(pkg.version,'1.98.65-v98.63.9.17');
  assert.match(html,/data-bottom-nav="calc"[^>]*>[\s\S]*?<span>Calculator<\/span>/);
  assert.match(css,/#app-container:has\(#screen-calc\.active\) > \.app-header\s*\{\s*display:none!important;/);
  assert.match(css,/#screen-calc\.active > \.calc-display\s*\{[^}]*flex-basis:46%!important/s);
  assert.match(css,/#screen-calc\.active > \.main-keypad\s*\{[^}]*flex:1 1 54%!important/s);
});
test('currency converter removes explanatory copy but retains controls and selected values',()=>{
  const html=read('index.html'), css=read('assets/css/app.css');
  assert.match(html,/id="cur-from"/); assert.match(html,/id="cur-to"/);
  assert.match(html,/id="cur-amount"/); assert.match(html,/id="btn-cur-swap"/);
  assert.match(html,/id="screen-currencies"[\s\S]*class="dock-keypad currency-dock-keypad/);
  assert.match(css,/#screen-currencies \.card-title,\s*#screen-currencies \.currency-rate-note/s);
  assert.match(css,/#screen-currencies \.currency-refresh-label\s*\{\s*display:none!important;/);
});
test('unit converter removes headings and helper copy but keeps selectors and keypad',()=>{
  const html=read('index.html'), css=read('assets/css/app.css');
  for(const id of ['unit-category','unit-from','unit-to','unit-input-val','unit-result-val','btn-unit-swap','unit-convert-action'])
    assert.ok(html.includes(`id="${id}"`),`missing ${id}`);
  assert.match(css,/#screen-units \.card-title,\s*#screen-units #unit-note/s);
  assert.match(html,/id="screen-units"[\s\S]*class="dock-keypad"/);
});
