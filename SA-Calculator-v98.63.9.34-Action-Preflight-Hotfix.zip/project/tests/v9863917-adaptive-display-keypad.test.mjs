import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
const css = read('assets/css/app.css');
const js = read('assets/js/app.js');
const pkg = JSON.parse(read('package.json'));

test('v98.63.9.17 uses the reference 36:64 portrait display/keypad split', () => {
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.match(css, /v98\.63\.9\.17 — reference-matched larger keypad/);
  assert.match(css, /\.calc-display\s*\{[^}]*flex:0 0 36%!important/s);
  assert.match(css, /\.main-keypad\s*\{[^}]*flex:0 0 64%!important/s);
});

test('key buttons are larger while 4x5 layout and double-width zero remain', () => {
  assert.match(css, /button\.key-btn\s*\{[^}]*height:96%!important/s);
  assert.match(css, /button\.key-btn\.zero-key\s*\{[^}]*grid-column:span 2!important/s);
  assert.match(css, /grid-template-rows:repeat\(5,minmax\(0,1fr\)\)!important/);
});

test('editable expression uses measured shrink range before horizontal scroll', () => {
  assert.match(js, /const maxFont = 30;\s*const minFont = 18;/);
  assert.match(js, /At the 18px readability floor/);
});

test('live preview is dynamically measured, has a 56-to-22px range, and overrides legacy CSS', () => {
  assert.match(js, /const maxSize = 56;\s*const minSize = 22;/);
  assert.match(js, /setProperty\('font-size', `\$\{rawSize\}px`, 'important'\)/);
});

test('committed result dynamically fits 64-to-22px without changing canonical calculation state', () => {
  assert.match(js, /const maxSize = 64;\s*const minSize = 22;/);
  assert.match(js, /const canonical = String\(STATE\.calcVal \?\? '0'\)/);
  assert.match(js, /display-only precision adaptation/);
});
